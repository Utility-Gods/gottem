# Gottem v1.2.0

This is the Gottem application version 1.2.0.

## Running the Application

Choose the appropriate executable for your platform:
- Windows: gottem_windows_amd64.exe
- macOS: gottem_darwin_amd64
- Linux: gottem_linux_amd64

Run the executable from the command line.

For more information, visit: [Your project URL]

## Changelog

[Add your changelog here]

